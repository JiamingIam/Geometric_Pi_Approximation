# Understanding π Through Tangent Circles

[中文](README.md)

**From two right triangles to a polygon-doubling recurrence**  
Tangent Circles and π: A Geometric Exploration

> Research notes · 2026-11-19  
> This document records a geometric exploration starting with tangent circles. The resulting recurrence is equivalent to the classical Archimedean method of regular-polygon approximation. The focus is on the construction, derivation, and verification, rather than a claim to a new algorithm for π.

## 1. The starting question

Suppose many identical small circles are arranged around a larger circle, with their centers on its circumference and adjacent small circles externally tangent. As the small circles become more numerous and smaller, **does the sum of their diameters approach the circumference of the large circle?**

We can take the question one step further: can we compute their radii successively, using only the Pythagorean theorem, arithmetic, and square roots, without supplying the numerical value of π in advance?

The answer is yes. The key observation is that the distance between adjacent centers equals a small-circle diameter. Consequently, the perimeter of the regular polygon connecting these centers equals the sum of those diameters.

We first study one large circle and one small circle, then apply the resulting segment relationships to a recurrence for an entire ring of small circles.

## 2. The basic model: two circles, a tangent, and notation

![Two identical geometric models side by side: the left shows the circles, segments, and vertices; the right adds the length labels a, r, R, d, and e.](assets/tangent-models-en.png)

**Figure 1 | The same model shown side by side.** Both panels use exactly the same coordinates and proportions for the circles, vertices, and segments. The right panel adds length labels for comparison. The illustration uses $r/R=0.6$ to keep the short segments visible; the geometric relations below hold for every $0<r<R$. This illustrative ratio need not correspond to a closed ring containing an integer number of small circles.

Let the large circle have center $O$ and radius $R$. The small circle has center $C$ on the circumference of the large circle and radius $r$. Draw a tangent from $O$ to the small circle, touching it at $T$. Extend ray $OT$ until it meets the large circle at $P$. Join $OC$, $TC$, and $PC$.

Because $0<r<R$, point $O$ lies outside the small circle, so the tangent exists. Moreover, $OT<R$, so $T$ lies strictly between $O$ and $P$.

| Symbol | Geometric object | Definition or relationship |
|---|---|---|
| $O$ | Center of the large circle | — |
| $C$ | Center of the small circle | $OC=R$ |
| $T$ | Tangency point on the small circle | $TC\perp OT$ |
| $P$ | Intersection of ray $OT$ with the large circle | $OP=R$; $O,T,P$ are collinear in that order |
| $a$ | Length of the tangent segment $OT$ | $a=\sqrt{R^2-r^2}$ |
| $r$ | Small-circle radius $TC$ | $0<r<R$ |
| $R$ | Large-circle radius | $R=OC=OP$ |
| $d$ | Length of the extension segment $TP$ | $d=R-a$ |
| $e$ | Length of chord $PC$ | $e=\sqrt{r^2+d^2}$ |

Although $a+d=R$, neither $a$ nor $d$ individually represents the large-circle radius. Segment $e$ is a chord of the large circle and should not be identified directly with a small-circle radius.

### 2.1 The first right triangle

A tangent is perpendicular to the radius at the point of tangency, so $\triangle OTC$ is right-angled at $T$. The Pythagorean theorem gives

$$
a^2+r^2=R^2,
\qquad a=\sqrt{R^2-r^2}.
$$

Since $OP=R$ and $OT+TP=OP$,

$$
d=R-a=R-\sqrt{R^2-r^2}
=\frac{r^2}{R+\sqrt{R^2-r^2}}.
$$

The final expression is algebraically equivalent to the preceding one but avoids directly subtracting two nearly equal numbers. We will use this form later.

### 2.2 The second right triangle

Since $PT$ and $OT$ lie on the same line, $\triangle PTC$ is also right-angled at $T$. Therefore,

$$
e^2=d^2+r^2.
$$

Combining $r^2=R^2-a^2$ with $d=R-a$ gives

$$
\begin{aligned}
e^2
&=d^2+(R^2-a^2)\\
&=d^2+(R-a)(R+a)\\
&=d(d+R+a)\\
&=2Rd.
\end{aligned}
$$

This yields the central identity of the construction:

$$
\boxed{e^2=2Rd},
\qquad
\boxed{e=\sqrt{2R\left(R-\sqrt{R^2-r^2}\right)}}.
$$

This is an **exact relationship** for every $0<r<R$, not an approximation requiring the small circle to be sufficiently small.

## 3. How the lengths change as the small circle shrinks

Fix $R>0$ and let $r\to0^+$. Then $a\to R$, $d\to0$, and $e\to0$. Their relative rates of change are more informative:

$$
\lim_{r\to0^+}\frac{d}{r}=0,
\qquad
\lim_{r\to0^+}\frac{d}{r^2}=\frac{1}{2R},
\qquad
\lim_{r\to0^+}\frac{e}{r}=1.
$$

Thus $d$ approaches zero faster than $r$, while the ratio of $e$ to $r$ approaches one. This explains why the short chord and the small-circle radius become nearly equal in the local limit.

Series expansions describe these relationships more precisely:

$$
\begin{aligned}
a&=R-\frac{r^2}{2R}-\frac{r^4}{8R^3}
+O\!\left(\frac{r^6}{R^5}\right),\\[3pt]
d&=\frac{r^2}{2R}+\frac{r^4}{8R^3}
+O\!\left(\frac{r^6}{R^5}\right),\\[3pt]
e&=r+\frac{r^3}{8R^2}+\frac{7r^5}{128R^4}
+O\!\left(\frac{r^7}{R^6}\right).
\end{aligned}
$$

In particular,

$$
\lim_{r\to0^+}\frac{e-r}{r^3}=\frac{1}{8R^2}.
$$

These limits help explain the local geometry; they are not required computational steps in the recurrence below.

## 4. Arranging the small circles in a ring

![Twelve adjacent, externally tangent small circles have their centers on a large circle. Connecting the centers produces an inscribed regular dodecagon with side length 2r_n.](assets/circle-necklace-en.png)

**Figure 2 | The sum of small-circle diameters equals a polygon perimeter.** The small-circle centers are equally spaced on the circumference of a circle of radius $R$, and adjacent small circles are externally tangent. The green segments connect adjacent centers, each with length $2r_n$.

The arrangement must satisfy three conditions:

1. There are an integer number $n\ge3$ of small circles, all with the same radius $r_n$.
2. Their centers are equally spaced on the circumference of the large circle.
3. Adjacent small circles are externally tangent, including the last and the first.

Under these conditions, $r_n$ is determined by $n$ and $R$ and cannot be chosen independently. Connecting adjacent centers gives a regular $n$-gon inscribed in the large circle, with perimeter

$$
\ell_n=2nr_n.
$$

The quantities being added are the **small-circle diameters**, not their circumferences or the total length of the outer boundary of the ring.

For finite $n$, the inscribed polygon has a smaller perimeter than the large circle. As $n$ increases without bound,

$$
\ell_n\longrightarrow2\pi R,
\qquad
\boxed{\pi=\lim_{n\to\infty}\frac{nr_n}{R}}.
$$

The same relationship can be expressed trigonometrically as

$$
\frac{r_n}{R}=\sin\left(\frac{\pi}{n}\right).
$$

This expression is useful for verifying the geometry and analyzing convergence. However, if the purpose is to calculate an unknown numerical value of π, we cannot first substitute that value into this expression to generate $r_n$. The next section derives a recurrence that requires no numerical input for π.

## 5. From $n$ small circles to $2n$ small circles

Let $C$ and $C'$ be adjacent small-circle centers, so $CC'=2r_n$. Draw a tangent from $O$ to the small circle centered at $C$ with radius $r_n$, **choosing the tangent ray inside $\angle COC'$**. Retain the notation $T$ and $P$ from Figure 1.

Why is $P$ the midpoint of the minor arc $CC'$? Let $M$ be the midpoint of chord $CC'$. Then $CM=r_n$ and $OM\perp CC'$. The right triangles $OCM$ and $OCT$ have equal hypotenuses of length $R$ and corresponding legs of length $r_n$. Their congruence, together with the choice of tangent ray, shows that rays $OT$ and $OM$ coincide. The perpendicular bisector of the chord passes through the large-circle center and bisects the corresponding minor arc. Hence $P$ is its midpoint.

Inserting such a point on each minor arc converts the regular $n$-gon into a regular $2n$-gon. Its new side length is $PC=e$. For the new small circles to remain externally tangent to their neighbors, their diameter must equal this new side length. Thus

$$
2r_{2n}=e.
$$

Substituting the identity from Section 2 gives

$$
\boxed{
r_{2n}=\sqrt{\frac{R\left(R-\sqrt{R^2-r_n^2}\right)}{2}}
}.
\tag{1}
$$

The radii $r_n$ and $r_{2n}$ belong to two different sets of small circles. The existing small circles shrink, and new circles of the same smaller size are added at the inserted vertices.

### 5.1 A numerically stable equivalent form

When $r_n/R$ is small, Equation (1) subtracts nearly equal numbers and may lose significant digits in finite-precision arithmetic. Rationalizing the inner difference yields

$$
\boxed{
r_{2n}=r_n\sqrt{\frac{R}{2\left(R+\sqrt{R^2-r_n^2}\right)}}
}.
\tag{2}
$$

With $x_n=r_n/R$, this becomes

$$
\boxed{
x_{2n}=\frac{x_n}{\sqrt{2\left(1+\sqrt{1-x_n^2}\right)}}
}.
\tag{3}
$$

Equations (2) and (3) avoid the direct subtractive cancellation in Equation (1), but finite precision and rounding errors still limit the calculation.

### 5.2 Starting with a regular hexagon

The side length of a regular hexagon equals the radius of its circumcircle. Therefore,

$$
r_6=\frac R2,
\qquad x_6=\frac12.
$$

Set $n_k=6\cdot2^k$. Repeated application of Equation (3) generates $x_6,x_{12},x_{24},\ldots$, giving

$$
\pi_k=n_kx_{n_k},
\qquad
\lim_{k\to\infty}\pi_k=\pi.
$$

The initial condition and recurrence use only integers, arithmetic, and square roots. They require no prior numerical value of π.

Alternatively, the approximation $p_n=nx_n$ can be updated directly:

$$
\boxed{
p_{2n}=p_n\sqrt{\frac{2}{1+\sqrt{1-(p_n/n)^2}}}
},
\qquad p_6=3.
\tag{4}
$$

## 6. Upper and lower bounds at every step

The inscribed regular $n$-gon provides a lower bound, while the circumscribed regular $n$-gon provides an upper bound:

$$
\boxed{
L_n=nx_n<\pi<\frac{nx_n}{\sqrt{1-x_n^2}}=U_n
}.
\tag{5}
$$

Here $L_n$ and $U_n$ are dimensionless bounds for π. By contrast, $\ell_n$ in Section 4 is a polygon perimeter with units of length.

The upper bound follows directly from similar figures. Scale the inscribed regular $n$-gon about $O$ by the factor $R/a_n$, where $a_n=\sqrt{R^2-r_n^2}$ is its apothem. Each side of the enlarged polygon is then tangent to the large circle. The circumscribed polygon has perimeter $2nr_nR/a_n$; division by $2R$ gives the upper bound in Equation (5).

### 6.1 Numerical values

The following values were computed using Equation (3) and are **rounded to the nearest value with nine decimal places**. They are displayed approximations to exact bounds; each displayed value should not automatically be treated as a certified, directionally rounded bound.

| Number of small circles $n$ | Displayed lower bound $L_n$ | Displayed upper bound $U_n$ |
|---:|---:|---:|
| 6 | 3.000000000 | 3.464101615 |
| 12 | 3.105828541 | 3.215390309 |
| 24 | 3.132628613 | 3.159659942 |
| 48 | 3.139350203 | 3.146086215 |
| 96 | 3.141031951 | 3.142714600 |
| 192 | 3.141452472 | 3.141873050 |
| 384 | 3.141557608 | 3.141662747 |
| 768 | 3.141583892 | 3.141610177 |
| 1,536 | 3.141590463 | 3.141597034 |
| 3,072 | 3.141592106 | 3.141593749 |

For example, rounding the exact lower and upper bounds outward to nine decimal places when $n=3072$ gives

$$
3.141592105<\pi<3.141593749.
$$

For comparison, $\pi\approx3.141592653589793\ldots$. This reference value was not used in the recurrence.

### 6.2 Rate of convergence

Using the theoretical expression $x_n=\sin(\pi/n)$ to analyze the error gives

$$
L_n=n\sin\left(\frac\pi n\right)
=\pi-\frac{\pi^3}{6n^2}+O(n^{-4}).
$$

For sufficiently large $n$, each doubling of the number of sides reduces the leading error by approximately a factor of four. Here π appears in the error analysis, not as an input to the numerical recurrence.

The method offers clear geometric meaning and a direct derivation. It is not an efficient choice for computing very large numbers of digits of π.

## 7. Pseudocode

```text
n ← 6
x ← 0.5

repeat:
    lower ← n × x
    upper ← n × x / sqrt(1 − x × x)
    output(n, lower, upper)

    if upper − lower < tolerance:
        stop

    x ← x / sqrt(2 × (1 + sqrt(1 − x × x)))
    n ← 2 × n
```

In exact arithmetic, `lower` and `upper` are strict theoretical bounds. In ordinary floating-point arithmetic, rounding may make them equal or destroy the strict enclosure. The stopping condition alone therefore cannot certify arbitrary accuracy. For a computer-certified enclosure, use interval arithmetic with outward rounding and increase the working precision when necessary.

## 8. Relationship to existing work

This approach has two components: **a geometric interpretation using tangent small circles** and **a numerical recurrence that doubles the number of sides of a regular polygon**. Their relationship to prior work is summarized below.

| Component of this exploration | Related work | Supported conclusion |
|---|---|---|
| Approximating the large-circle circumference by summing small-circle diameters | Archimedean approximation using inscribed polygon perimeters; see [1] | Both methods calculate the same geometric quantity |
| Doubling the side count using a square-root recurrence | Leung's lecture notes; see [2] | The core recurrences are identical after a change of variable |
| Rationalizing a difference of nearly equal numbers to improve numerical stability | Page 10, Equation (6), of Leung's notes; see [2] | This stabilization has an existing published precedent |
| Equal tangent circles centered at the vertices of a regular polygon | A 2018 discussion of circle necklaces; see [3] | The same arrangement has been discussed publicly, although the question was not about computing π |

The equivalence can be checked directly. Set $n_k=6\cdot2^k$ and $t_k=x_{n_k}^2$. Squaring Equation (3) gives

$$
t_{k+1}=\frac{t_k}{2\left(1+\sqrt{1-t_k}\right)}.
$$

This is the stable recurrence in [2]. That treatment starts with a square, whereas this exploration starts with a regular hexagon. The initial conditions differ, but the recurrence has the same structure.

The exploratory sequence retained here starts with a circle tangent and two right triangles, derives $e^2=2Rd$, and then identifies $e$ as the new chord length after doubling the number of sides. This sequence offers one geometric explanation of the classical algorithm. The search did not establish the earliest source of this exact presentation and does not support a claim of originality or priority.

## 9. Formula reference

| Purpose | Formula |
|---|---|
| Tangent length | $a=\sqrt{R^2-r^2}$ |
| Extension segment | $d=R-a=r^2/(R+a)$ |
| New chord length | $e^2=2Rd$ |
| New small-circle radius | $r_{2n}=e/2$ |
| Stable recurrence | $x_{2n}=x_n/\sqrt{2(1+\sqrt{1-x_n^2})}$ |
| Initial condition | $x_6=1/2$ |
| Lower bound for π | $L_n=nx_n$ |
| Upper bound for π | $U_n=nx_n/\sqrt{1-x_n^2}$ |
| Limit defining π | $\pi=\lim_{k\to\infty}n_kx_{n_k}$, with $n_k=6\cdot2^k$ |

## 10. Questions for further exploration

- How can purely geometric relationships produce tighter upper and lower bounds for π?
- How do the computational cost and error compare when starting from different regular polygons?
- Can successive approximations be combined to cancel the leading error term and accelerate convergence?
- How can theoretical enclosures be turned into certified numerical intervals in finite-precision arithmetic?

These are possible directions for further work, not claims of results established in this document.

## References

[1] Joel Feldman. [**Archimedes' (Approximate) Computation of π**](https://www.math.ubc.ca/~feldman/m120/archimedesPi.pdf). University of British Columbia, September 14, 2012. Presents inscribed and circumscribed polygons and their doubling recurrences in modern notation.

[2] K. Ming Leung. [**Another Algorithm for Computing π Attributable to Archimedes: Avoiding Cancellation Errors**](https://cse.engineering.nyu.edu/~mleung/CS3734/s04/ch01/Archimedes1.pdf). Polytechnic University, revised February 21, 2004; currently hosted on an NYU website. Equation (6) on page 10 gives the stable recurrence equivalent to the one used here.

[3] Vepir. [**Necklaces made out of circles lying on vertices of regular polygons**](https://math.stackexchange.com/questions/2882767/necklaces-made-out-of-circles-lying-on-vertices-of-regular-polygons). Mathematics Stack Exchange, August 14, 2018. A public question-and-answer discussion of necklaces of equal tangent circles, cited here only as evidence of a previously discussed geometric arrangement.

Sources accessed and checked on November 19, 2026. All figures were drawn from the geometric relationships described here; none were copied from the cited sources.
