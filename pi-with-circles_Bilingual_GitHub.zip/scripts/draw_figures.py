"""Reproduce the geometrically exact figures with matplotlib and numpy.

Run from any directory: python scripts/draw_figures.py
The PNG files are used by README.md; SVG files are scalable alternatives.
"""
from pathlib import Path
import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import Circle, Polygon

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
ASSETS.mkdir(parents=True, exist_ok=True)
parser = argparse.ArgumentParser()
parser.add_argument('--lang', choices=['zh', 'en'], default='zh')
LANG = parser.parse_args().lang
SUFFIX = '-en' if LANG == 'en' else ''

def tr(zh, en):
    return en if LANG == 'en' else zh

available = {f.name for f in fm.fontManager.ttflist}
for family in ["Noto Sans CJK JP", "Noto Sans CJK SC", "Microsoft YaHei", "SimHei", "Arial Unicode MS"]:
    if family in available:
        plt.rcParams["font.family"] = family
        break
plt.rcParams.update({"axes.unicode_minus": False, "svg.fonttype": "path",
                     "mathtext.fontset": "stix", "font.size": 12})

INK = "#21374b"
BLUE = "#567caa"
TEAL = "#087f83"
ORANGE = "#c28520"
RED = "#cc5148"
PURPLE = "#985c9c"


def line(ax, p, q, color, width=2.5, **kw):
    ax.plot([p[0], q[0]], [p[1], q[1]], color=color, lw=width,
            solid_capstyle="round", zorder=4, **kw)


def label(ax, text, xy, color=INK, size=17, **kw):
    ax.text(*xy, text, color=color, fontsize=size, ha="center", va="center",
            zorder=8, bbox={"facecolor":"white", "edgecolor":"none", "alpha":0.85,
                           "pad":0.3}, **kw)


def tangent_panel(ax, annotated):
    R, r = 1.0, 0.6
    O, C = np.array([0., 0.]), np.array([1., 0.])
    a = np.sqrt(R*R-r*r)
    T = np.array([a*a/R, a*r/R])
    P = T * R/a
    # The same geometry and drawing operations are used in both panels.
    ax.add_patch(Circle(O, R, ec=BLUE, fc="#eef4fa", lw=2.0, zorder=1))
    ax.add_patch(Circle(C, r, ec=ORANGE, fc="#fff7e8", lw=2.0, alpha=.85, zorder=2))
    ax.add_patch(Polygon([O, T, C], fc="#d4eeed", ec="none", alpha=.95, zorder=3))
    ax.add_patch(Polygon([T, P, C], fc="#eadcf0", ec="none", alpha=.95, zorder=3))
    for p, q, col in [(O,C,BLUE),(O,T,TEAL),(T,P,RED),(T,C,ORANGE),(P,C,PURPLE)]:
        line(ax,p,q,col)
    u = (O-T)/np.linalg.norm(O-T)
    v = (C-T)/np.linalg.norm(C-T)
    for direction, col in [(u,TEAL),(-u,RED)]:
        w = .045
        corner = [T+w*direction, T+w*(direction+v), T+w*v]
        ax.plot(*np.array(corner).T, color=col, lw=1.0, zorder=6)
    for name, point, offset in [("O",O,(-.065,-.085)),("C",C,(.065,-.085)),
                                ("T",T,(-.080,.035)),("P",P,(.045,.080))]:
        ax.scatter(*point,s=19,color=INK,zorder=7)
        label(ax,"$"+name+"$",point+offset,size=17)
    if annotated:
        for name, pos, col in [("a",(.275,.305),TEAL),("r",(.747,.205),ORANGE),
                                ("R",(.48,-.085),BLUE),("d",(.670,.648),RED),
                                ("e",(.993,.333),PURPLE)]:
            label(ax,"$"+name+"$",pos,col,size=20)
    ax.set(xlim=(-1.12,1.73),ylim=(-1.11,1.18),aspect="equal")
    ax.axis("off")
    # Check the construction, independently of labels and display coordinates.
    assert np.isclose(np.linalg.norm(T-C),r)
    assert np.isclose(np.dot(T-O,T-C),0)
    assert np.isclose(np.linalg.norm(P),R)
    assert np.isclose(np.linalg.norm(P-C)**2,2*R*(R-a))


fig, axes = plt.subplots(1,2,figsize=(13.4,6.7),facecolor="white")
fig.subplots_adjust(left=.025,right=.975,top=.82,bottom=.12,wspace=.10)
fig.text(.05,.947,tr("两个圆，一组几何关系","Two circles, one geometric relationship"),fontsize=23,color=INK,weight="bold")
fig.text(.05,.893,tr("左右模型的形状、尺寸与顶点位置完全一致；右侧增加线段长度标注。","Both panels use identical geometry; the right panel adds segment-length labels."),fontsize=11.5,color="#5c6e7a")
titles = [tr("A  几何模型","A  Geometric model"),tr("B  相同模型 · 字母标注","B  Same model with length labels")]
for ax, annotated, title in zip(axes,[False,True],titles):
    tangent_panel(ax,annotated)
    ax.set_title(title,loc="left",fontsize=13,color=INK,pad=12)
fig.text(.255,.085,tr("$O,T,P$ 共线；$TC \\perp OP$","$O,T,P$ are collinear; $TC \\perp OP$"),ha="center",fontsize=13,color=INK)
fig.text(.745,.085,"$a=OT$    $r=TC$    $R=OC=OP$",ha="center",fontsize=13,color=INK)
fig.text(.745,.040,"$d=TP$    $e=PC$    $a+d=R$",ha="center",fontsize=13,color=INK)
fig.savefig(ASSETS/f"tangent-models{SUFFIX}.png",dpi=180,facecolor="white")
fig.savefig(ASSETS/f"tangent-models{SUFFIX}.svg",facecolor="white")
plt.close(fig)

fig, ax = plt.subplots(figsize=(8.7,7.5),facecolor="white")
fig.subplots_adjust(left=.06,right=.94,top=.82,bottom=.13)
fig.text(.07,.945,tr("一圈小圆，连接成一个正多边形","A ring of circles and an inscribed polygon"),fontsize=18 if LANG == 'en' else 20,color=INK,weight="bold")
fig.text(.07,.893,tr("圆心在大圆上，相邻小圆外切；每条绿色边的长度都是小圆直径。","Adjacent circles touch; each green side equals one small-circle diameter."),fontsize=10.5,color="#5c6e7a")
n,R = 12,1.0
r = R*np.sin(np.pi/n)  # Rendering only; not used to compute pi.
theta = np.linspace(0,2*np.pi,n,endpoint=False)
centers = np.column_stack((R*np.cos(theta),R*np.sin(theta)))
ax.add_patch(Circle((0,0),R,ec=BLUE,fc="#eef4fa",lw=2.1,zorder=1))
for c in centers:
    ax.add_patch(Circle(c,r,ec=ORANGE,fc="#fff4df",lw=1.3,alpha=.75,zorder=2))
ax.add_patch(Polygon(centers,closed=True,fill=False,ec=TEAL,lw=2.1,zorder=3))
ax.scatter(*centers.T,s=14,color=TEAL,zorder=5)
ax.scatter(0,0,s=22,color=INK,zorder=5)
line(ax,np.zeros(2),centers[0],BLUE,width=1.4,ls="--")
label(ax,"$R$",(.5,-.075),BLUE)
label(ax,"$O$",(-.065,-.075))
label(ax,"$C$",centers[0]+np.array([.07,-.09]))
label(ax,"$C'$",centers[1]+np.array([.09,.025]))
p,q=centers[0],centers[1]
mid=(p+q)/2
label(ax,"$2r_n$",mid+np.array([.16,.06]),TEAL,size=19)
end = centers[6] + r*np.array([np.cos(2.2),np.sin(2.2)])
line(ax,centers[6],end,ORANGE,width=2)
label(ax,"$r_n$",(centers[6]+end)/2+np.array([-.10,.03]),ORANGE,size=17)
ax.set(xlim=(-1.43,1.49),ylim=(-1.34,1.37),aspect="equal")
ax.axis("off")
fig.text(.5,.065,"$n=12$     $\\ell_n=2nr_n$     $L_n=nr_n/R$",ha="center",fontsize=16,color=INK)
assert np.allclose(np.linalg.norm(np.roll(centers,-1,axis=0)-centers,axis=1),2*r)
fig.savefig(ASSETS/f"circle-necklace{SUFFIX}.png",dpi=180,facecolor="white")
fig.savefig(ASSETS/f"circle-necklace{SUFFIX}.svg",facecolor="white")
plt.close(fig)
print("Created 2 PNG figures and 2 SVG figures; geometric assertions passed.")
